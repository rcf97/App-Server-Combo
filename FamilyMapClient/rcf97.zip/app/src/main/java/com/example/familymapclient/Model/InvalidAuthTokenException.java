package com.example.familymapclient.Model;

public class InvalidAuthTokenException extends Exception {
    public InvalidAuthTokenException() { super(); }
    public InvalidAuthTokenException(String message) { super(message); }
}
