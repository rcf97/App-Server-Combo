package com.example.familymapclient;

public interface LoginListener {
    void onLogin();
    void onLogout();
    void onRefresh();
}
