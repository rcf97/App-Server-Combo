package com.example.familymapclient;

import com.example.familymapclient.Model.DataCache;
import com.example.familymapclient.Model.EventExt;
import com.example.familymapclient.Model.HttpClient;
import com.example.familymapclient.Model.InvalidAuthTokenException;
import com.example.familymapclient.Model.PersonExt;

import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;

import Result.PersonResult;

import static org.junit.Assert.*;

public class DataCacheTest {
    public static final String url = "http://192.168.1.141:8081";
    private static final String authToken = "7ab31d85-ece1-42ae-8319-b09f2437477f";

    @Test
    public void familyRelationshipsTest() throws MalformedURLException, InvalidAuthTokenException {
        HttpClient client = new HttpClient();
        DataCache dataCache = DataCache.getInstance();
        PersonResult result = client.getPersons(new URL(url + "/person"), authToken);
        dataCache.loadData(result);
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        for (int i = 0; i < result.getPersons().length; i++) {
            if (result.getPersons()[i].getID().equals("Sheila_Parker")) {
                dataCache.setUser(result.getPersons()[i]);
            }
        }
        dataCache.organize();
        Map<String, PersonExt> persons = dataCache.getPersons();
        PersonExt blaine = persons.get("Blaine_McGary");
        assertEquals(blaine.getFather().getID(), blaine.getFatherID());
        assertEquals(blaine.getMother().getID(), blaine.getMotherID());
        assertEquals(blaine.getSpouse().getID(), blaine.getSpouseID());
        assertEquals(blaine.getChild().getID(), "Sheila_Parker");
    }

    @Test
    public void filterSideTest() throws MalformedURLException, InvalidAuthTokenException {
        HttpClient client = new HttpClient();
        DataCache dataCache = DataCache.getInstance();
        PersonResult result = client.getPersons(new URL(url + "/person"), authToken);
        dataCache.loadData(result);
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        for (int i = 0; i < result.getPersons().length; i++) {
            if (result.getPersons()[i].getID().equals("Sheila_Parker")) {
                dataCache.setUser(result.getPersons()[i]);
            }
        }
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        dataCache.organize();
        dataCache.setFathersSide(false);
        assertEquals(dataCache.getEvents().size(), 11);
    }

    @Test
    public void filterGenderTest() throws MalformedURLException, InvalidAuthTokenException {
        HttpClient client = new HttpClient();
        DataCache dataCache = DataCache.getInstance();
        PersonResult result = client.getPersons(new URL(url + "/person"), authToken);
        dataCache.loadData(result);
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        for (int i = 0; i < result.getPersons().length; i++) {
            if (result.getPersons()[i].getID().equals("Sheila_Parker")) {
                dataCache.setUser(result.getPersons()[i]);
            }
        }
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        dataCache.organize();
        dataCache.setFilterFemale(false);
        dataCache.setFilterMale(false);
        assertEquals(dataCache.getEvents().size(), 0);
    }

    @Test
    public void chronology() throws MalformedURLException, InvalidAuthTokenException {
        HttpClient client = new HttpClient();
        DataCache dataCache = DataCache.getInstance();
        PersonResult result = client.getPersons(new URL(url + "/person"), authToken);
        dataCache.loadData(result);
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        for (int i = 0; i < result.getPersons().length; i++) {
            if (result.getPersons()[i].getID().equals("Sheila_Parker")) {
                dataCache.setUser(result.getPersons()[i]);
            }
        }
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        dataCache.organize();

        ArrayList<EventExt> events = dataCache.getUser().getEvents();
        boolean pass = true;
        if (!events.get(0).getID().equals("Sheila_Birth") ||
                !events.get(1).getID().equals("Sheila_Marriage") ||
                !events.get(2).getType().toLowerCase().equals("completed asteroids") ||
                !events.get(3).getType().toLowerCase().equals("completed asteroids") ||
                !events.get(4).getID().equals("Sheila_Death")) {
                pass = false;
        }
        assertTrue(pass);
    }

    @Test
    public void chronologyHard() throws MalformedURLException, InvalidAuthTokenException {
        HttpClient client = new HttpClient();
        DataCache dataCache = DataCache.getInstance();
        PersonResult result = client.getPersons(new URL(url + "/person"), authToken);
        dataCache.loadData(result);
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        for (int i = 0; i < result.getPersons().length; i++) {
            if (result.getPersons()[i].getID().equals("Sheila_Parker")) {
                dataCache.setUser(result.getPersons()[i]);
            }
        }
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        dataCache.organize();

        ArrayList<EventExt> events = dataCache.getPerson("Frank_Jones").getEvents();
        boolean pass = true;
        if (!events.get(0).getID().equals("Jones_Frog") ||
                !events.get(1).getID().equals("Jones_Marriage")) {
            pass = false;
        }
        assertTrue(pass);
    }

    @Test
    public void search() throws MalformedURLException, InvalidAuthTokenException {
        HttpClient client = new HttpClient();
        DataCache dataCache = DataCache.getInstance();
        PersonResult result = client.getPersons(new URL(url + "/person"), authToken);
        dataCache.loadData(result);
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        for (int i = 0; i < result.getPersons().length; i++) {
            if (result.getPersons()[i].getID().equals("Sheila_Parker")) {
                dataCache.setUser(result.getPersons()[i]);
            }
        }
        dataCache.organize();

        ArrayList<PersonExt> persons = dataCache.searchPersons("");
        ArrayList<EventExt> events = dataCache.searchEvents("");

        assertEquals(persons.size(), 8);
        assertEquals(events.size(), 16);

    }

    @Test
    public void searchMed() throws MalformedURLException, InvalidAuthTokenException {
        HttpClient client = new HttpClient();
        DataCache dataCache = DataCache.getInstance();
        PersonResult result = client.getPersons(new URL(url + "/person"), authToken);
        dataCache.loadData(result);
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        for (int i = 0; i < result.getPersons().length; i++) {
            if (result.getPersons()[i].getID().equals("Sheila_Parker")) {
                dataCache.setUser(result.getPersons()[i]);
            }
        }
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        dataCache.organize();

        ArrayList<PersonExt> persons = dataCache.searchPersons("j");
        ArrayList<EventExt> events = dataCache.searchEvents("q");

        assertEquals(persons.size(), 2);
        assertEquals(events.size(), 2);
    }

    @Test
    public void searchHard() throws MalformedURLException, InvalidAuthTokenException {
        HttpClient client = new HttpClient();
        DataCache dataCache = DataCache.getInstance();
        PersonResult result = client.getPersons(new URL(url + "/person"), authToken);
        dataCache.loadData(result);
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        for (int i = 0; i < result.getPersons().length; i++) {
            if (result.getPersons()[i].getID().equals("Sheila_Parker")) {
                dataCache.setUser(result.getPersons()[i]);
            }
        }
        dataCache.loadData(client.getEvents(new URL(url + "/event"), authToken));
        dataCache.organize();

        ArrayList<PersonExt> persons = dataCache.searchPersons("abc");
        ArrayList<EventExt> events = dataCache.searchEvents("abc");

        assertEquals(persons.size(), 0);
        assertEquals(events.size(), 0);
    }

}