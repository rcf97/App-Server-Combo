package com.example.familymapclient;

import com.example.familymapclient.Model.HttpClient;

import org.junit.Assert;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;

import Request.LoginRequest;
import Request.RegisterRequest;
import Result.EventResult;
import Result.LoginResult;
import Result.PersonResult;
import Result.RegisterResult;

public class HttpClientTest {

    public static final String url = "http://192.168.1.141:8081";
    private static final String authToken = "7ab31d85-ece1-42ae-8319-b09f2437477f";
    private static final String wrongAuthToken = "7ab31d85-ece1-42ae-8319-b09f2437477g";
    public HttpClient client;

    @Test
    public void LoginPass() throws MalformedURLException {
        this.client = new HttpClient();
        LoginRequest request = new LoginRequest("sheila", "parker");
        LoginResult result = this.client.sendRequest(new URL(url + "/user/login"), request);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void LoginFail() throws MalformedURLException {
        this.client = new HttpClient();
        LoginRequest request = new LoginRequest("bogus", "user");
        LoginResult result = this.client.sendRequest(new URL(url + "/user/login"), request);
        Assert.assertFalse(result.isSuccess());
    }

    @Test
    public void RegisterPass() throws MalformedURLException {
        this.client = new HttpClient();
        RegisterRequest request = new RegisterRequest("Hulk15", "gammarays",
                "greenguy@comcast.net", "Bruce", "Banner", "m");
        RegisterResult result = this.client.sendRequest(new URL(url + "/user/register"), request);
        Assert.assertTrue(result.isSuccess());
    }

    @Test
    public void RegisterFail() throws MalformedURLException {
        this.client = new HttpClient();
        RegisterRequest request = new RegisterRequest("patrick", "betty",
                "greenguy@comcast.net", "Bruce", "Banner", "m");
        RegisterResult result = this.client.sendRequest(new URL(url + "/user/register"), request);
        Assert.assertFalse(result.isSuccess());
    }

    @Test
    public void getPersonsPass() throws MalformedURLException {
        this.client = new HttpClient();
        PersonResult result = client.getPersons(new URL(url + "/person"), this.authToken);
        Assert.assertTrue(result.isSuccess());
        if (result.isArray()) {
            Assert.assertEquals(result.getPersons().length, 8);
        }
    }

    @Test
    public void getPersonsFail() throws MalformedURLException {
        this.client = new HttpClient();
        PersonResult result = client.getPersons(new URL(url + "/person"), this.wrongAuthToken);
        Assert.assertFalse(result.isSuccess());
    }

    @Test
    public void getEventsPass() throws MalformedURLException {
        this.client = new HttpClient();
        EventResult result = client.getEvents(new URL(url + "/event"), this.authToken);
        Assert.assertTrue(result.isSuccess());
        if (result.isArray()) {
            Assert.assertEquals(result.getEvents().length, 16);
        }
    }

    @Test
    public void getEventsFail() throws MalformedURLException {
        this.client = new HttpClient();
        EventResult result = client.getEvents(new URL(url + "/event"), this.wrongAuthToken);
        Assert.assertFalse(result.isSuccess());
    }
}